const {SQSClient, ReceiveMessageCommand, DeleteMessageCommand} = require("@aws-sdk/client-sqs");
const {
    EC2Client,
    DescribeInstancesCommand,
    TerminateInstancesCommand,
    RunInstancesCommand
} = require("@aws-sdk/client-ec2");
const {
    Route53Client,
    ListResourceRecordSetsCommand,
    ChangeResourceRecordSetsCommand
} = require("@aws-sdk/client-route-53");
const {CloudWatchClient, GetMetricStatisticsCommand} = require("@aws-sdk/client-cloudwatch");
const {DynamoDBClient, UpdateItemCommand, ScanCommand} = require("@aws-sdk/client-dynamodb");
const https = require('https');
const Redis = require('ioredis')

exports.handler = async (event) => {
    const region = process.env.region;
    const SQS_URL = process.env.SQS_URL;
    const dynamoTable = process.env.dynamoTable;
    const sqsClient = new SQSClient({region});
    const ec2Client = new EC2Client({region});
    const route53Client = new Route53Client({region});
    const cloudWatchClient = new CloudWatchClient({region});
    const dynamoDBClient = new DynamoDBClient({region});
    const defaultInstanceDomainName = "openvidu0.syeong.link.";

    const sqsInput = {
        AttributeNames: ["All"],
        MaxNumberOfMessages: 1,
        MessageAttributeNames: ["All"],
        QueueUrl: SQS_URL,
        WaitTimeSeconds: 10,
        VisibilityTimeout: 10
    };

    const redis = new Redis({
        host: 'redis.egg-signal',
        port: 6379,
    });

    const command = new ReceiveMessageCommand(sqsInput);
    const response = await sqsClient.send(command);

    console.log('sqs response: ', response);

    if (!response.Messages) {
        console.log('메시지 없음!');
        await scaleDown(ec2Client, cloudWatchClient, route53Client, dynamoDBClient, dynamoTable, defaultInstanceDomainName);
        return;
    }

    const message = response.Messages[0];
    console.log('메시지 있음!', message.MessageAttributes);

    if (!message.MessageAttributes.sessionId) {
        console.log('잘못된 형식의 메시지 입니다!')
    }

    const sessionId = message.MessageAttributes.sessionId.StringValue

    await scaleUpAndCheckConnection(ec2Client, cloudWatchClient, route53Client, dynamoDBClient, dynamoTable, sessionId, SQS_URL, message.ReceiptHandle, sqsClient, redis);
};

async function scaleDown(ec2Client, cloudWatchClient, route53Client, dynamoDBClient, dynamoTable, defaultInstanceDomainName) {
    console.log('스케일 다운 시작!')
    const instances = await listInstances(ec2Client, 'running');
    const instancesToTerminate = [];

    for (const instance of instances) {
        if (isInstanceOlderThan(instance, 5) && !(await isInstanceUnderDomain(route53Client, instance.PublicIpAddress, defaultInstanceDomainName))) {
            console.log('생긴지 5분이 지났으면서, initial instance 가 아닌 인스턴스 존재!')
            const cpuUtilization = await getCpuUtilization(cloudWatchClient, instance.InstanceId);
            if (cpuUtilization < 10) {
                console.log('그 중 CPU 사용량이 10% 이하인 인스턴스 존재!')
                instancesToTerminate.push(instance.InstanceId);
                let domain = await getInstanceDomain(route53Client, instance.PublicIpAddress);
                if (domain) {
                    domain = domain.replace(/\.$/, '');
                    console.log('initial instance 가 아니면서 생긴지 5분이 넘었고, CPU 를 10% 이상 사용하지 않고 있는 인스턴스 존재! -> 이건 없애야해', domain)
                    await updateDynamoDB(dynamoDBClient, dynamoTable, domain, "true");
                    const webHookURL = process.env.INFRA_PIPELINE_WEBHOOK;
                    const content = `⛳️ **AWS CodePipeline Notification**\n\n**Instance 를 삭제했어요! domain: ${domain}**`;
                    const response = await fetch(webHookURL, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({content})
                    });

                    if (!response.ok) {
                        throw new Error(`Webhook request failed with status: ${response.status}`);
                    }
                }
            }
        }
    }

    if (instancesToTerminate.length > 0) {
        console.log('삭제해야 할 인스턴스가 있어요!', instancesToTerminate)
        await terminateInstances(ec2Client, instancesToTerminate);
    } else {
        console.log('삭제해야 할 인스턴스가 없어요!')
    }
}

async function scaleUpAndCheckConnection(ec2Client, cloudWatchClient, route53Client, dynamoDBClient, dynamoTable, sessionId, SQS_URL, ReceiptHandle, sqsClient, redis) {
    console.log('스케일 업 시작!')
    const instances = await listInstances(ec2Client, 'running');

    for (const instance of instances) {
        if (isInstanceOlderThan(instance, 5)) {
            const cpuUtilization = await getCpuUtilization(cloudWatchClient, instance.InstanceId);
            console.log(cpuUtilization);
            if (cpuUtilization < 30) {
                let domain = await getInstanceDomain(route53Client, instance.PublicIpAddress);
                domain = domain.replace(/\.$/, '');
                console.log(domain)
                console.log(await isDomainHealthy(domain))
                if (domain && await isDomainHealthy(domain)) {
                    console.log('생긴지 5분 이상 되었고, cpu 50% 미만 사용중이면서 health check 통과한 인스턴스가 있어요!', domain)
                    // 큐에서 메시지 삭제
                    const deleteParams = {QueueUrl: SQS_URL, ReceiptHandle: ReceiptHandle};
                    await sqsClient.send(new DeleteMessageCommand(deleteParams));
                    await redis.set(`sessionId:${sessionId}:openViduUrl`, `https://${domain}/`)
                    return;
                }
            }
        }
    }

    console.log('현재 바로 사용 가능한 인스턴스가 없어요!')
    for (const instance of instances) {
        if (!isInstanceOlderThan(instance, 5)) {
            console.log('생성 후 초기화중인 인스턴스가 있어요! 인스턴스를 새로 생성하지 않아요')
            return
        }
    }
    const newInstances = await listInstances(ec2Client, 'pending', 'initializing');
    if (newInstances.length > 0) {
        console.log('생성중인 인스턴스가 있어요! 인스턴스를 새로 생성하지 않아요');
        return;
    }

    console.log('인스턴스를 새로 생성해요!')
    await launchNewInstance(ec2Client, route53Client, dynamoDBClient, dynamoTable);
}

async function listInstances(ec2Client, ...statuses) {
    const command = new DescribeInstancesCommand({
        Filters: [{Name: 'instance-state-name', Values: statuses}]
    });
    const response = await ec2Client.send(command);
    return response.Reservations.flatMap(reservation => reservation.Instances);
}

function isInstanceOlderThan(instance, minutes) {
    const launchTime = new Date(instance.LaunchTime);
    return (new Date() - launchTime) / 1000 / 60 > minutes;
}

async function getCpuUtilization(cloudWatchClient, instanceId) {

    const command = new GetMetricStatisticsCommand({
        Namespace: 'AWS/EC2',
        MetricName: 'CPUUtilization',
        Dimensions: [{Name: 'InstanceId', Value: instanceId}],
        StartTime: new Date(Date.now() - 30000), // 마지막 30초
        EndTime: new Date(),
        Period: 30,
        Statistics: ['Maximum']
    });

    const response = await cloudWatchClient.send(command);
    const datapoints = response.Datapoints;
    if (datapoints.length > 0) {
        return datapoints[0].Maximum;
    }
    return 0;
}

async function isInstanceUnderDomain(route53Client, instanceIp, domainName) {
    const command = new ListResourceRecordSetsCommand({HostedZoneId: process.env.HostedZoneId});
    const response = await route53Client.send(command);
    const records = response.ResourceRecordSets;
    return records.some(record => record.Name === domainName && record.ResourceRecords.some(r => r.Value.includes(instanceIp)));
}

async function terminateInstances(ec2Client, instanceIds) {
    const command = new TerminateInstancesCommand({InstanceIds: instanceIds});
    await ec2Client.send(command);
}

async function getInstanceDomain(route53Client, instanceIp) {
    console.log('instanceIp: ', instanceIp);
    const command = new ListResourceRecordSetsCommand({HostedZoneId: process.env.HostedZoneId});
    const response = await route53Client.send(command);
    const records = response.ResourceRecordSets;
    const record = records.find(record => {
        return record.ResourceRecords ? record.ResourceRecords.some(r => r.Value.includes(instanceIp)) : false;
    });

    console.log('record: ', record);

    return record ? record.Name : null;
}

async function launchNewInstance(ec2Client, route53Client, dynamoDBClient, dynamoTable) {
    const availableDomain = await getAvailableDomain(dynamoDBClient, dynamoTable);
    if (!availableDomain) {
        console.log('No available domain found');
        return;
    }

    console.log('새 인스턴스를 생성해요!', availableDomain)

    const userDataScript = `#!/bin/bash
            apt update -y
            apt-get install -y ca-certificates curl
            install -m 0755 -d /etc/apt/keyrings
            curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
            chmod a+r /etc/apt/keyrings/docker.asc
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
            apt-get update -y
            apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
            cd /opt
            curl https://s3-eu-west-1.amazonaws.com/aws.openvidu.io/install_openvidu_latest.sh -o install_openvidu_latest.sh
            bash install_openvidu_latest.sh &
            PID=$!
            sleep 100
            if ps -p $PID > /dev/null; then
            echo "OpenVidu installation script timed out."
            kill $PID
            exit 1
            fi
            cd /opt/openvidu
            sed -i 's/DOMAIN_OR_PUBLIC_IP=/DOMAIN_OR_PUBLIC_IP=${availableDomain}/g' .env
            sed -i 's/OPENVIDU_SECRET=/OPENVIDU_SECRET=hongaldan/g' .env
            sed -i 's/CERTIFICATE_TYPE=selfsigned/CERTIFICATE_TYPE=letsencrypt/g' .env
            sed -i 's/LETSENCRYPT_EMAIL=user@example.com/LETSENCRYPT_EMAIL=visioner2168@gmail.com/g' .env
            ./openvidu start
            `;
    const userDataBase64 = Buffer.from(userDataScript).toString('base64');

    const runInstanceCommand = new RunInstancesCommand({
        ImageId: 'ami-062cf18d655c0b1e8',
        InstanceType: 't3.small',
        MinCount: 1,
        MaxCount: 1,
        UserData: userDataBase64,
        SubnetId: process.env.subnetId,
        KeyName: 'clion', // Key pair 이름
        SecurityGroupIds: [process.env.securityGroupId],
        TagSpecifications: [{ResourceType: 'instance', Tags: [{Key: 'Name', Value: availableDomain}]}]
    });

    const runInstanceResponse = await ec2Client.send(runInstanceCommand);
    const instanceId = runInstanceResponse.Instances[0].InstanceId;
    const wait = (time) => new Promise((resolve) => setTimeout(resolve, time));
    await wait(3000);
    const instanceIp = await getInstanceIp(ec2Client, instanceId);

    const changeBatch = {
        Changes: [{
            Action: 'UPSERT',
            ResourceRecordSet: {
                Name: availableDomain,
                Type: 'A',
                TTL: 60,
                ResourceRecords: [{Value: instanceIp}]
            }
        }]
    };

    const changeCommand = new ChangeResourceRecordSetsCommand({
        HostedZoneId: process.env.HostedZoneId,
        ChangeBatch: changeBatch
    });

    await route53Client.send(changeCommand);
    await updateDynamoDB(dynamoDBClient, dynamoTable, availableDomain, 'false');

    console.log(`${availableDomain} 을 등록했어요!`)
    const webHookURL = process.env.INFRA_PIPELINE_WEBHOOK;
    const content = `⛳️ **AWS CodePipeline Notification**\n\n**Instance 를 생성했어요! domain: ${availableDomain}**`;
    const response = await fetch(webHookURL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({content})
    });

    if (!response.ok) {
        throw new Error(`Webhook request failed with status: ${response.status}`);
    }
}

async function getAvailableDomain(dynamoDBClient, dynamoTable) {
    const scanCommand = new ScanCommand({
        TableName: dynamoTable,
        FilterExpression: 'isAvailable = :val',
        ExpressionAttributeValues: {':val': {S: "true"}}
    });

    const response = await dynamoDBClient.send(scanCommand);
    if (response.Items.length > 0) {
        return response.Items[0].Domain.S;
    }
    return null;
}

async function getInstanceIp(ec2Client, instanceId) {
    const describeCommand = new DescribeInstancesCommand({InstanceIds: [instanceId]});
    const response = await ec2Client.send(describeCommand);
    return response.Reservations[0].Instances[0].PublicIpAddress;
}

async function updateDynamoDB(dynamoDBClient, dynamoTable, domain, isAvailable) {
    const updateCommand = new UpdateItemCommand({
        TableName: dynamoTable,
        Key: {'Domain': {S: domain}},
        UpdateExpression: 'SET isAvailable = :val',
        ExpressionAttributeValues: {':val': {S: isAvailable}}
    });
    await dynamoDBClient.send(updateCommand);
}

async function isDomainHealthy(domain) {
    return new Promise((resolve, reject) => {
        const options = {hostname: domain, port: 443, method: 'GET'};

        const req = https.request(options, (res) => {
            resolve(res.statusCode === 200);
        });

        req.on('error', (e) => {
            console.error(e);
            resolve(false);
        });

        req.end();
    });
}
